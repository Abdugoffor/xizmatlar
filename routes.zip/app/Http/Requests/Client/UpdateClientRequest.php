<?php

namespace App\Http\Requests\Client;

use Illuminate\Foundation\Http\FormRequest;

class UpdateClientRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        $rules = [
            'title' => 'required|string|max:255',
            'photo' => 'nullable|file|max:10240',
            'is_active' => 'required|boolean',

        ];

        // $rules = array_merge(
        //     $rules,
        //     validateTranslation('title')
        // );

        return $rules;
    }

    public function messages()
    {
        return [
            'title.required'       => getTranslation('title is required'),
            'title.string'          => getTranslation('title must be a string'),
            'title.max'            => getTranslation('title must not exceed 255 characters'),
            'photo.file'        => getTranslation('photo must be a file'),
            'photo.max'         => getTranslation('photo must not exceed 10 MB'),
            'is_active.required'   => getTranslation('is active is required'),
            'is_active.boolean'   => getTranslation('is active must be true or false'),

        ];
    }
}