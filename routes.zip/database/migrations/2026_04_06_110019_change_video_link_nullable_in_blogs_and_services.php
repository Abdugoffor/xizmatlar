<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('blogs', function (Blueprint $table) {
            $table->string('video_link')->nullable()->change();
        });

        Schema::table('services', function (Blueprint $table) {
            $table->string('video_link')->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('blogs', function (Blueprint $table) {
            $table->string('video_link')->nullable(false)->change();
        });

        Schema::table('services', function (Blueprint $table) {
            $table->string('video_link')->nullable(false)->change();
        });
    }
};
